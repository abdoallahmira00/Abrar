مشروع تطبيق أبرار (مستقل)

المحتويات:
- index.html: التطبيق وصفحة «عن التطبيق» وفيها اسم المطوّر عبدالله ميرة ودعاء له.
- assets/: صور الأيقونات.
- .github/workflows/build.yml: إعداد بناء APK تلقائيًا عبر GitHub Actions.

طريقة رفع المشروع إلى مستودع Abrar الجديد:
1) افتح مستودع Abrar على GitHub.
2) من Add file اختر Upload files.
3) ارفع محتويات مجلد abrar_patch (ملف index.html ومجلد assets ومجلد .github).
4) اضغط Commit changes.
5) افتح Actions، واختر Build APK - Al Abrar، ثم Run workflow.
6) بعد انتهاء البناء بنجاح، افتح نتيجة التشغيل ونزّل Artifact باسم al-abrar-apk، ثم فك ضغطه وثبّت APK.

ملاحظة: التطبيق مستقل عن نور ويستخدم هوية Android جديدة: com.abrar.app.
